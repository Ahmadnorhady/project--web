<?php

  // Set time limit to infinate, stop the PHP
  // script from timing out this overrides
  // anything set in php.ini
  set_time_limit(0);

  // MSSQL Details
  $dbserver = "ADMIN-PC\SQLEXPRESS";
  $dbuser   = "adminreport";
  $dbpass   = "Suhran8899";
  $dbname   = "otomax";
  $dbconn   = 0;

  // MySQL Details
  $mydbserver = "localhost";
  $mydbuser   = "adminreport";
  $mydbpass   = "Suhran8899";
  $mydbname   = "report";
  $mydbconn   = 0;

$dbconn=mssql_connect($dbserver,$dbuser,$dbpass);
mssql_select_db($dbname, $dbconn) or die("Unable to Open The MS-Sql Database");

$query="SELECT
kode,
nama,
saldo,
kode_upline,
pin
FROM reseller
ORDER BY kode";

$mydbconn=mysql_connect($mydbserver,$mydbuser,$mydbpass);
mysql_select_db($mydbname, $mydbconn) or die("Unable to Open The MySql Database");

  $qt=mssql_query($query);
  while($nt=mssql_fetch_array($qt))
  
{

echo
"
$nt[kode],
$nt[nama],
$nt[saldo],
$nt[kode_upline],
$nt[pin]
";

echo "<br>";
    
$myquery = "INSERT INTO reseller
(
kode,
nama,
saldo,
kode_upline,
pin
)
VALUES
(
'".$nt['kode']."',
'".$nt['nama']."',
'".$nt['saldo']."',
'".$nt['kode_upline']."',
'".$nt['pin']."'
)";

mysql_query($myquery) or Die("MySQL Query Failed " . mysql_error());

}

if ($myquery) 
{
    echo 'Proses Upload Selesai...';
}
else
{
    echo 'Proses Upload Gagal...';
}

  // Close the connections
  mssql_close($dbconn);
  mysql_close($mydbconn);

?>