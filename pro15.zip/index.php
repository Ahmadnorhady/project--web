<!DOCTYPE html>
<html>
<head>
	 <title>My Web</title>
	 <link href="css/style.css" rel="stylesheet" type="text/css">
	 <meta name="viewport" content="width=device-width, initial-scale=1.0">
	 <meta charset="UTF-8">
</head>
<body>
	<div class="container">
		<header>
			<div class="profile">
					<div class="title">
		  				<span id="header"><a class="home" href="index.php">MY WEB</a></span>
		  			</div>
		  			<div class="above-container">
				  		<div class="above-menu">
				  			<ul class="abmenu">
				  				<li><a href="#">Cetak Struk</a>&nbsp;|</li>
				  				<li><a href="#">Media Transaksi</a>&nbsp;|</li>
				  				<li><a href="#">Download App</a>&nbsp;|</li>
				  				<li><a href="#">Kontak</a></li>
				  			</ul>
				  		</div>
				  	</div>
			</div>
		</header>
		<nav>	
			<div class="menu">			
				<ul class="topmenu">
				  <li><a href="index.php">Home</a></li>
				  <li><a href="#news">Registrasi</a></li>
				  <li class="dropdown">
				    <a href="javascript:void(0)" class="dropbtn">Harga Produk</a>
				    <div class="dropdown-content">
				      	<a href="#">Pulsa Regular</a>
				     	<a href="#">Paket Data</a>
				      	<a href="#">PLN Prabayar</a>
				      	<a href="#">PPOB</a>
				    </div>
				  </li>
				  <li><a href="#news">Deposit</a></li>
				  <li><a href="#news">Format Transaksi</a></li>
				</ul>
			</div>
			<select id="mainMenu">
       			<option value="index.php">Home</option>
        		<option value="categories.html">Harga Produk</option>
          		<option value="html.html">+ Pulsa Regular</option>
          		<option value="css.html">+ Paket Data</option>
          		<option value="php.html">+ PLN Prabayar</option>
          		<option value="javascript.html">+ PPOB</option>
        		<option value="our_product.html">Deposit</option>
          		<option value="ebook.html">Format Transaksi</option>
      		</select>
		</nav>
		<div class="page-center">
		<aside>
				<div class="sidebar">
					<div class="login">
						<?php
						include('login.php');
						if(isset($_SESSION['login_user'])){
						header("location: user.php");
						}
						?>
				  			<form action="" method="post">
				  				<h3 class="caption">LOGIN WEBREPORT</h3>
				   				<input id="name" name="username" type="text" placeholder="ID AGEN">
				   				<input id="password" name="password" type="password" placeholder="PASSWORD">
				   				<br>
				   				<button class="btn-login" type="submit" name="submit" id="submit" value="Login">LOGIN</button>
				  			</form>
				 	</div>
					<div class="contact">
						<h4>EMAIL</h4>
						<hr>
						<p>example@gmail.com</p>
						<h4>OFFICE</h4>
						<hr>
						<p>Jln. Example No.</p>
					</div>
				</div>
		</aside>
		<main>
			<div class="page">
				<h1>Selamat datang di website</h1>	
			</div>
		</main>
		<footer>
			<div class="footer">
				<div class="con-menu">
					<div class="menu-footer">
						<h4>EMAIL</h4>
						<hr>
						<p>example@gmail.com</p>
						<h4>OFFICE</h4>
						<hr>
						<p>Jln. Example No.</p>
					</div>
				</div>
				<div class="page-footer">
					<p class="copyright">Copyright &#169; All Right Reserved <a class="cp" href="#" title="Re-pay.id">My Web</a> Design By <a class="cp" href="#" title="ahmadnorhady">Re-pay.id</a></p>
				</div>
			</div>
		</footer>
		</div>
	</div>
</body>
</html>