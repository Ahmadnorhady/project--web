<?php
include('session.php');
?>
<!DOCTYPE html>
<html>
<head>
	 <title>My Web | Web Report</title>
	 <meta charset="UTF-8">
	 <link href="css/style.css" rel="stylesheet" type="text/css">
	 <link rel="stylesheet" type="text/css" href="css/table-style.css">

</head>
<body>
	<div class="container">
		<header>
			<div class="profile">
		  		<div class="title">
		  			<span id="header"><a class="home" href="index.php">MY WEB</a></span>
		  		</div>
		  		<div class="above-container">
				  	<div class="above-menu">
				  		<ul class="abmenu">
				  			<li><a href="#">Cetak Struk</a>&nbsp;|</li>
				  			<li><a href="#">Media Transaksi</a>&nbsp;|</li>
				  			<li><a href="#">Download App</a>&nbsp;|</li>
				  			<li><a href="#">Kontak</a></li>
				  		</ul>
				  	</div>
				  	<div class="above-logout">
				  			<p class="logout">ID AGEN : <?php echo $login_session; ?> &nbsp;
				  			<a href="logout.php">LOGOUT</a></p>
				 	</div>
				 </div>
			</div>
		</header>
		<nav>
			<div class="menu">			
				<ul class="topmenu">
				  <li><a href="index.php">Home</a></li>
				  <li><a href="#news">Registrasi</a></li>
				  <li class="dropdown">
				    <a href="javascript:void(0)" class="dropbtn">Harga Produk</a>
				    <div class="dropdown-content">
				      	<a href="#">Pulsa Regular</a>
				     	<a href="#">Paket Data</a>
				      	<a href="#">PLN Prabayar</a>
				      	<a href="#">PPOB</a>
				    </div>
				  </li>
				  <li><a href="#news">Deposit</a></li>
				  <li><a href="#news">Format Transaksi</a></li>
				</ul>
			</div>
		</nav>
		<div class="page-center">
		<aside>
				<div class="sidebar">
					<div class="menu-sidebar">
						<ul>
							<li><a href="downline.php">DOWNLINE</a></li>
							<li><a href="#">TRANSAKSI</a></li>
							<li><a href="#">MUTASI</a></li>
							<li><a href="logout.php">HALAMAN UTAMA</a></li>
						</ul>
					</div>
					<div class="contact">
						<h4>EMAIL</h4>
						<hr>
						<p>example@gmail.com</p>
						<h4>OFFICE</h4>
						<hr>
						<p>Jln. Example No.</p>
					</div>
				</div>
		</aside>
		<main>
			<div class="table">
				<?PHP
				//check if the starting row variable was passed in the URL or not
				if (!isset($_GET['startrow']) or !is_numeric($_GET['startrow'])) {
	  			//we give the value of the starting row to 0 because nothing was found in URL
	 			$startrow = 0;
				//otherwise we take the value from the URL
				} else {
	  			$startrow = (int)$_GET['startrow'];
				}
				?>
				<?
				//this part goes after the checking of the $_GET var
				$result = mysql_query("SELECT kode, nama, saldo, kode_upline FROM reseller WHERE kode_upline = '$login_session' LIMIT $startrow, 15")or
				die(mysql_error());
	   			$num=Mysql_num_rows($result);
	       		if($num>0)
	       		?>
				<table>
					<tr class="head">
						<th>KODE</th>
						<th>NAMA</th>
						<th>SALDO</th>
						<th>KODE UPLINE</th>
					</tr>
				<?
				while ($row = mysql_fetch_array($result))
				{
				echo "<tr>";
				echo "<td>";
				echo $row['kode'];
				echo "</td>";
				echo "<td>";
				echo $row['nama'];
				echo "</td>";
				echo "<td>";
				echo $row['saldo'];
				echo "</td>";
				echo "<td>";
				echo $row['kode_upline'];
				echo "</td>";
				echo "</tr>";
				}
				?>
				</table>
				<span class="pagination-page">
				<p class="pg">
				<?
				$prev = $startrow - 10;
				//only print a "Previous" link if a "Next" was clicked
				if ($prev >= 0)
		    	echo '<a href="'.$_SERVER['PHP_SELF'].'?startrow='.$prev.'">Sblmnya |</a>';
				//now this is the link..
				echo '<a href="'.$_SERVER['PHP_SELF'].'?startrow='.($startrow+10).'"> Lanjut</a>';
				?>
				</p>
				</span>
			</div>
		</main>
		<footer>
			<div class="footer">
				<div class="page-footer">
				<p class="copyright">Copyright &#169; All Right Reserved Design By <a class="cp" href="#" title="ahmadnorhady">Re-pay.id</a></p>
				</div>
			</div>
		</footer>
		</div>
	</div>
</body>
</html>