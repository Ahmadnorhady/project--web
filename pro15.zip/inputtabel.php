<?php

set_time_limit(0);

$servername = "localhost";
$username = "adminreport";
$password = "Suhran8899";
$databasename = "report";

# Check Database
$db = new mysqli($servername, $username, $password, $databasename);

if($db->connect_error){
	die('Koneksi Gagal: ' . $db->connect_error);
}


$sql = "CREATE TABLE IF NOT EXISTS reseller (
  kode varchar(20) NOT NULL PRIMARY KEY,
  nama varchar(50) NOT NULL,
  saldo int NULL,
  kode_upline varchar(20) NOT NULL,
  pin varchar(10) NULL
)";

# Execute Query
if ($db->query($sql) === TRUE) {
    echo "Tabel berhasil dibuat";
} else {
    echo "Tabel gagal dibuat: " . $db->error;
}

?>