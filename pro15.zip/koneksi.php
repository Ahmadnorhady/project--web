<?php

set_time_limit(0);

$servername = "localhost";
$username = "adminreport";
$password = "Suhran8899";
$databasename = "report";

# Check Database
$db = new mysqli($servername, $username, $password, $databasename);

if($db->connect_error){
die('Koneksi Gagal: ' . $db->connect_error); }

?>	