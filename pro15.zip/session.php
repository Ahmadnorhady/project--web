<?php
$connection = mysql_connect("localhost", "adminreport", "Suhran8899");
$db = mysql_select_db("report", $connection);
session_start();
$user_check=$_SESSION['login_user'];
$ses_sql=mysql_query("select kode from reseller where kode='$user_check'", $connection);
$row = mysql_fetch_assoc($ses_sql);
$login_session =$row['kode'];
if(!isset($login_session)){
	mysql_close($connection);
	header('Location: index.php');
}
?>